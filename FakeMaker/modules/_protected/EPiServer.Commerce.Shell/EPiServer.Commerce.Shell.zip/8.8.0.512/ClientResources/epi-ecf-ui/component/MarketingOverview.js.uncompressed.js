require({cache:{
'url:epi-ecf-ui/component/templates/MarketingOverview.html':"<div>\n\t<div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-ecf-ui/widget/MarketingToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\n    <div data-dojo-type=\"epi-ecf-ui/widget/CampaignItemList\" data-dojo-attach-point=\"campaignItemList\"></div>\n</div>"}});
define("epi-ecf-ui/component/MarketingOverview", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-geometry",
    "dojo/when",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi
    "epi/shell/_ContextMixin",
// resources
    "dojo/text!./templates/MarketingOverview.html",
// Widgets in the template
    "../widget/MarketingToolbar",
    "../widget/CampaignItemList"
], function (
    declare,
    lang,
    domGeometry,
    when,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi
    _ContextMixin,
// resources
    template
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContextMixin], {
        // summary:
        //      This is the initializer of Marketing Overview.

        templateString: template,

        layout: function () {
            // summary:
            //		Layout the children widgets.
            // tags:
            //		protected

            var toolbarSize = domGeometry.getMarginBox(this.toolbar.domNode);

            // Set the size of the pricing overview to be the content height minus the toolbar height.
            this.campaignItemList.resize({
                h: this._contentBox.h - toolbarSize.h,
                w: this._contentBox.w
            });
        },

        startup: function () {
            this.inherited(arguments);
            when(this.getCurrentContext(), lang.hitch(this, this.contextChanged));
        },

        contextChanged: function (ctx, callerData) {
            this.toolbar.update({
                currentContext: ctx
            });
        }
    });
});