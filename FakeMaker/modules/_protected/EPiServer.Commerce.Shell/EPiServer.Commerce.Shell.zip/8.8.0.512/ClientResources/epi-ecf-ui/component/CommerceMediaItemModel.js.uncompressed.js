﻿define("epi-ecf-ui/component/CommerceMediaItemModel", [
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/when",

// EPi Framework
    "epi/dependency",

// EPi CMS
    "epi-cms/contentediting/editors/model/CollectionEditorItemModel",
    "epi-cms/core/PermanentLinkHelper",
// Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.commercemediacollectioneditor"
], function (

// Dojo
    array,
    declare,
    lang,
    Deferred,
    when,

// EPi Framework
    dependency,

// EPi CMS
    CollectionEditorItemModel,
    PermanentLinkHelper,
// Resources
    resources
) {

    return declare([CollectionEditorItemModel], {
        // summary:
        //      The commerce media item model.
        // module:
        //      "epi-ecf-ui/component/commercemediaitemmodel"
        // description:
        //      That supports: edit, delete, create commerce media link
        // tags:
        // public

        fromItemData: function (itemData) {
            // summary:
            //      Create item model object from raw item data.
            // itemData: Object
            //      The raw item data.
            // tags:
            //      public

            var df = new Deferred();

            // Store arguments so we can reuse them in another closure.
            var args = arguments;

            itemData.assetKey = itemData.assetKey || itemData.permanentUrl;

            when(PermanentLinkHelper.getContent(itemData.assetKey)).then(lang.hitch(this, function (content) {

                if (content) {
                    itemData.thumbnailUrl = content.thumbnailUrl;
                    itemData.assetName = content.name;
                    itemData.assetKey = content.permanentLink;
                    itemData.assetType = itemData.assetType || content.typeIdentifier;
                } else {
                    itemData.thumbnailUrl = itemData.assetKey;
                    itemData.assetName = resources.medianotfound;
                }

                //set default value for groupname and sortorder
                itemData.groupName = itemData.groupName || "default";
                itemData.sortOrder = itemData.sortOrder || 0;

                // After manipulating itemData we call fromItemData on base class to set the item data property names.
                this.inherited(args);

                df.resolve(this);
            }));

            return df;
        }

    });
});