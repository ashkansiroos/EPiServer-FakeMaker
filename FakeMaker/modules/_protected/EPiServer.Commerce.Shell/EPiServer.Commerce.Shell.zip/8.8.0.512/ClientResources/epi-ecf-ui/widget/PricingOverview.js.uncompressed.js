require({cache:{
'url:epi-ecf-ui/widget/templates/PricingOverview.html':"﻿<div class=\"epi-pricingOverview\">\r\n    <div data-dojo-attach-point=\"header\">\r\n        <div data-dojo-type=\"epi-cms/contentediting/NotificationBar\" data-dojo-attach-point=\"notificationBar\"></div>\r\n        <div class=\"epi-view-container\">\r\n            <h1 data-dojo-attach-point=\"heading\" class=\"dijitInline\">${resources.heading}</h1>\r\n            <div data-dojo-attach-point='filterNode' class=\"epi-filterHolder\">\r\n                <div class=\"epi-filterHolderLeading\">\r\n                    <button class=\"epi-mediumButton\"\r\n                            data-dojo-attach-event='onClick: _onShowNewPrice'\r\n                            data-dojo-attach-point=\"addNewPrice\"\r\n                            data-dojo-type=\"dijit/form/Button\"\r\n                            data-dojo-props=\"label: '${resources.buttons.addprice}', title:'${resources.buttons.addprice}', iconClass:'epi-iconPlus'\"></button>\r\n                </div>\r\n                <div class=\"epi-filterHolderCenter clearfix\">\r\n                    <label for=\"customergroup\">${resources.selectors.customergroup}</label>\r\n                    <select name=\"customergroup\"\r\n                            data-dojo-type=\"dijit/form/Select\"\r\n                            data-dojo-attach-point=\"customerGroupSelector\"\r\n                            data-dojo-attach-event='onChange: _onCustomerGroupChanged'></select>\r\n                    <label for=\"markets\">${resources.selectors.market}</label>\r\n                    <select name=\"markets\"\r\n                            data-dojo-type=\"epi-ecf-ui/widget/MarketSelector\"\r\n                            data-dojo-attach-point=\"marketSelector\"\r\n                            data-dojo-attach-event='onChange: _onMarketChanged'></select>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div data-dojo-attach-point='priceListNode'></div>\r\n    <div data-dojo-attach-point='addPriceNode'>\r\n        <div data-dojo-attach-point='newPriceFormNode'></div>\r\n        <div class=\"epi-floater--right\">\r\n            <button class=\"epi-mediumButton Salt\"\r\n                    data-dojo-attach-event='onClick: _onAddNewPrice'\r\n                    data-dojo-type=\"dijit/form/Button\"\r\n                    data-dojo-props=\"label: '${sharedResources.action.save}', title:'${sharedResources.action.save}'\"></button>\r\n            <button class=\"epi-mediumButton\"\r\n                    data-dojo-attach-event='onClick: _onCancelPrice'\r\n                    data-dojo-type=\"dijit/form/Button\"\r\n                    data-dojo-props=\"label: '${sharedResources.action.cancel}', title:'${sharedResources.action.cancel}'\"></button>\r\n        </div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/PricingOverview", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/when",
    "dojo/dom",
    "dojo/dom-construct",
    "dojo/dom-geometry",
    "dojo/dom-style",

// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/Select",
// dojox
    "dojox/html/entities",
// EPi Framework
    "epi/dependency",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/TypeDescriptorManager",
// EPi CMS
    "epi-cms/contentediting/NotificationBar", // used in template
// commerce
    "../contentediting/editors/PricingOverviewEditor",
    "../contentediting/ModelSupport",
    "./BackToPreviousViewNotification",
    "./MarketSelector",
    "./NewPrice",
    "./viewmodel/PricingOverviewModel",
// Resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview",
    "epi/i18n!epi/cms/nls/commerce.widget.market",
    "epi/i18n!epi/cms/nls/commerce.widget.customergroup",
    "epi/i18n!epi/nls/episerver.shared",
    "dojo/text!./templates/PricingOverview.html"
], function (
// dojo
    declare,
    lang,
    array,
    when,
    dom,
    domConstruct,
    domGeo,
    domStyle,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    Select,
// dojox
    entities,
// EPi Framework
    dependency,
    _ModelBindingMixin,
    TypeDescriptorManager,
// EPi CMS
    NotificationBar,
// commerce
    PricingOverviewEditor,
    ModelSupport,
    BackToPreviousViewNotification,
    MarketSelector,
    NewPrice,
    PricingOverviewModel,
// Resources
    resources,
    resDefaultMarket,
    resDefaultCustomerGroup,
    sharedResources,
    template
) {

    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
        // summary:
        //    Represents the widget to preview price for entries.
        // tags:
        //    public
        resources: resources,

        sharedResources: sharedResources,

        templateString: template,

        modelClassName: PricingOverviewModel,

        defaultCGItem: { id: "ALL", name: resDefaultCustomerGroup.defaultitem },

        priceMetadata: null,

        _backToPreviousViewNotification: null,

        // Map property name in view model to a list of properties in this widget
        modelBindingMap: {
            "markets": ["markets"],
            "customerGroups": ["customerGroups"]
        },

        postCreate: function () {
            this.inherited(arguments);

            if (!this.model && this.modelClassName) {
                var modelClass = declare(this.modelClassName);
                this.set("model", new modelClass());
            }
            this.model.populateData(); // load market list and customer groups.
            if (!this._backToPreviousViewNotification){
                this._backToPreviousViewNotification = new BackToPreviousViewNotification();
                this.own(
                    this._backToPreviousViewNotification.watch("notification", lang.hitch(this, this._defaultNotificationWatchHandler))
                );
            }
        },

        buildRendering: function() {
            this.inherited(arguments);
            if (!this.priceList){
                this.priceList = this.priceList || new PricingOverviewEditor();
                this.own(this.priceList);
                domConstruct.place(this.priceList.domNode, this.priceListNode);
            }
            if (!this.priceMetadata){
                when(dependency.resolve("epi.shell.MetadataManager").getMetadataForType("EPiServer.Commerce.Shell.ObjectEditing.InternalMetadata.PriceModel"), lang.hitch(this, function(metadata){
                    this.priceMetadata = metadata;
                }));
            }
        },

        showNotification: function () {
            // summary:
            //      Displays notification bar
            // tags:
            //      public
            this._backToPreviousViewNotification.showNotification();
        },

        _defaultNotificationWatchHandler: function (/*String*/name, /*Object*/oldValue, /*Object*/newValue) {
            // summary:
            //      Add/remove notification to/from notification bar
            // tags:
            //      private

            if (oldValue) {
                this.notificationBar.remove(oldValue);
            }

            if (newValue && newValue.content) {
                this.notificationBar.add(newValue);
            }

            this.layout();
        },

        layout: function () {
            // summary:
            //      Layout the pricing overview editor.
            // tags:
            //      protected

            var headerSize = domGeo.getMarginBox(this.header);

            this.priceList.resize({
                h: this._contentBox.h - headerSize.h,
                w: this._contentBox.w
            });
        },

        _setCustomerGroupsAttr: function (customerGroupList) {
            // summary:
            //      Sets customer group list. Let's bind this list to customer groups selector.
            // tags:
            //      private

            // Turn off change notifications while we make all these changes
            this.customerGroupSelector._onChangeActive = false;
            this.customerGroupSelector.removeOption(this.customerGroupSelector.options);

            if (customerGroupList) {
                customerGroupList.unshift(this.defaultCGItem);

                array.forEach(customerGroupList, function (customerGroup) {
                    this.customerGroupSelector.addOption({ label: entities.encode(customerGroup.name), value: entities.encode(customerGroup.id) });
                }, this);
            }

            // Turn on change notifications when we made all these changes
            this.customerGroupSelector._onChangeActive = true;
        },

        _onMarketChanged: function () {
            // summary:
            //      Filter the price list by selected market.
            var val = this.marketSelector.value;

            // Show market column when market seletor is ALL, otherwise hide it.
            if (this.priceList.grid){
                if (val === "ALL") {
                    this.priceList.grid.styleColumn("marketId", "display: table-cell;");
                } else {
                    this.priceList.grid.styleColumn("marketId", "display: none;");
                }
            }

            this.priceList.set("marketId", val);
        },

        _onShowNewPrice: function () {
            // summary:
            //      Add new price to a variation/package.
            var newPrice = this.model.getDefaultPrice();
            this._showNewPrice(true);
            this.newPriceWidget.set("value", newPrice);
        },

        _onAddNewPrice: function(){
            if (this.newPriceWidget.isValid()){
                var newPrice = this.newPriceWidget.get("value");
                newPrice.contentLink = this.model.content.contentLink;
                this.priceList.addPrice(newPrice);
                this._showNewPrice(false);
            }
        },

        _onCancelPrice: function(){
            this._showNewPrice(false);
        },

        _showNewPrice: function(show){
            this.heading.innerHTML = show ? this.resources.buttons.addprice : this.resources.heading;
            domStyle.set(this.addPriceNode, "display", show ? "" : "none");
            domStyle.set(this.priceListNode, "display", show ? "none" : "");
            domStyle.set(this.filterNode, "display", show ? "none" : "");
            if (this.newPriceWidget){
                this.newPriceWidget.destroy();
                this.newPriceWidget = null;
            }
            if (show){
                this._createNewPriceWidget();
                this._showNewPriceNotification();
            } else {
                this._backToPreviousViewNotification.showNotification();
            }
        },

        _createNewPriceWidget: function(){
            this.newPriceWidget = new NewPrice({
                doLayout: false,
                metadata: this.priceMetadata
            });
            this.newPriceWidget.startup();
            this.own(this.newPriceWidget);
            domConstruct.place(this.newPriceWidget.domNode, this.newPriceFormNode);
        },

        _showNewPriceNotification: function(){
            var notificationText = domConstruct.create("div", {
                innerHTML: resources.newpricenotification
            });
            this._backToPreviousViewNotification.set("notification", {
                content: notificationText,
                commands: [this._backToPreviousViewNotification.command]
            });
        },

        _onCustomerGroupChanged: function (){
            // summary:
            //      Filter the price list by selected customer group.
            var val = this.customerGroupSelector.value;

            // Show price type & price code column when customer group seletor is ALL, otherwise hide them.
            if (val === "ALL") {
                this.priceList.grid.styleColumn("priceCode", "display: table-cell;");
                this.priceList.grid.styleColumn("priceType", "display: table-cell;");
            } else {
                this.priceList.grid.styleColumn("priceCode", "display: none;");
                this.priceList.grid.styleColumn("priceType", "display: none;");
            }

            this.priceList.set("priceCode", val);
        },

        _setValueAttr: function (value) {
            // summary:
            //      Sets value for this widget.
            // value: content data
            //      Input content link to get data from.

            this.priceList.set("value", value.id);
            this._showNewPrice(false);
            //if the current content type has base type which is variation or package, then show add new price button
            if (TypeDescriptorManager.isBaseTypeIdentifier(value.dataType, ModelSupport.contentTypeIdentifier.variationContent) ||
                TypeDescriptorManager.isBaseTypeIdentifier(value.dataType, ModelSupport.contentTypeIdentifier.packageContent)) {
                domStyle.set(this.addNewPrice.domNode, "display", "");
                this.model.set("value", value.id);
            }
            else {
                domStyle.set(this.addNewPrice.domNode, "display", "none");
            }
        }
    });
});
