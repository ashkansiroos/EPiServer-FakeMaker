﻿define("epi-ecf-ui/widget/_HelpMixin", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/query",
    "dojo/dom-class",

// dijit
    "dijit/_WidgetBase",
    "dijit/form/Button",

// resources
    "epi/i18n!epi/nls/commerce.widget.helpmixin",

// Wait for the DOM to be ready before working with it
    "dojo/domReady!"
],

function (
// dojo
    declare,
    lang,
    query,
    domClass,

// dijit
    _WidgetBase,
    Button,

// resources
    i18n
) {
    return declare([_WidgetBase], {
        // summary:
        //      A mixin that turns helpButtonNode to a help button, to display/hide all help text, which is marked by epi-help css class.
        // tags:
        //      protected

        // showHelp: bool
        //      Flag to indicate whether the help messages should be visible or not. Set this as true will make help messages to be visible by default.
        showHelp: false,

        // helpContainerNode: domNode
        //      Represents the node that contains help message. By default, it will be this widget's domNode.
        //      This will be used to restrict the query, when querying all help messages.
        helpContainerNode: null,

        // helpMessageClassName: string
        //      Represents the CSS class name that will be used to query all help messages. In other word, help message should be made up with this class.
        helpMessageClassName: "epi-help",

        // activeMessageClassName: string
        //      Represents the CSS class name for the active state of help message.
        activeClassName: "is-active",

        // helpButtonClass: string
        //      CSS classes that will be used to decorate the help button.
        helpButtonClass: "epi-chromeless epi-mediumButton epi-help-button",

        // helpButtonIconClass: string
        //      Help button icon class.
        helpButtonIconClass: "epi-iconHelp",

        showHelpText: i18n.showhelp,

        hideHelpText: i18n.hidehelp,

        _helpButton: null,

        postCreate: function () {
            // summary:
            //		Decorates help button, as well as show/hide help messages, based on showHelp value.
            // tags:
            //		protected
            // exceptions:
            //      Error if the mixin was mixed to a widget that does not contain the 'helpButtonNode'.

            this.inherited(arguments);

            if (!this.helpButtonNode) {
                throw new Error("The _HelpMixin should be mixed to a widget that has a domNode reference stored in 'helpButtonNode' property");
            }

            this._helpButton = new Button({
                "class": this.helpButtonClass,
                iconClass: this.helpButtonIconClass,
                onClick: lang.hitch(this, function () {
                    this._toogleHelp();
                })
            }, this.helpButtonNode);
            this.own(this._helpButton); // make sure this Button will be cleaned up when the widget is destroyed.

            // update help messages's visible on load
            this.set("showHelp", this.showHelp);
        },

        _toogleHelp: function() {
            this.set("showHelp", !this.showHelp);
        },

        _setShowHelpAttr: function (val) {
            this._set("showHelp", val);
            this._updateHelpLabel(val);
            this._syncHelp(val);
        },

        _syncHelp: function (showHelp) {
            // summary:
            //		Shows/hides help messages, based on showHelp state.
            // tags:
            //		private

            // Restrict the query to this.helpContainerNode (or this.domNode by default) to make sure we will not update other widget's help messages.
            query("." + this.helpMessageClassName, this.helpContainerNode || this.domNode).forEach(function (node) {
                if (showHelp) {
                    domClass.add(node, this.activeClassName);
                } else {
                    domClass.remove(node, this.activeClassName);
                }
            }, this);
        },

        _updateHelpLabel: function (showHelp) {
            // summary:
            //		Updates help button text, based on the showHelp state.
            // tags:
            //		private

            if (this._helpButton) {
                this._helpButton.set("label", showHelp ? this.hideHelpText : this.showHelpText);
            }
        }
    });
});